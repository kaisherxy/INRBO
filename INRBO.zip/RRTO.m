% RRT-Based Optimizer: A Novel Metaheuristic Algorithm Based on Rapidly-Exploring Random Trees Algorithm
% Authors: G. J. Lai, T. Li and B. J. Shi
% Journal: IEEE Access 2025 Vol. 13 Pages 42744-42776
% DOI: 10.1109/ACCESS.2025.3547537
% https://ww2.mathworks.cn/matlabcentral/fileexchange/180256-rrt-based-optimizer

function [Best_Score, Best_Pos, CG_curve, Div] = RRTO(N, MaxIt, LB, UB, dim, fobj, MaxFEs,Func_name,Runs,r)

global initial_flag
initial_flag = 0;
C=10; 
FEs=0;    
Div=Inf(1,MaxIt); 
recordNum=MaxFEs/100+1;

%% Initialize Population and Evaluate Fitness
Position=zeros(N,dim);
Fitness = zeros(N, 1);
Rand_Seeds=load('input_data\Rand_Seeds.txt');
seed_ind=(dim*Func_name*Runs)/10-r-Runs;
seed_ind=mod(seed_ind,1000)+1;
run_seed=Rand_Seeds(seed_ind);
rng(run_seed,'twister');
for i=1:N
    Position(i,:)=LB+rand(1,dim).*(UB-LB);
    Fitness(i) = fobj(Position(i,:));
end
FEs = FEs + N;
rng('shuffle'); 

[~, Ind] = sort(Fitness);
Best_Score = Fitness(Ind(1));
Best_Pos = Position(Ind(1),:);

newFitness=zeros(N,1);

% Initialize convergence curve
CG_curve = Fitness(1);

%% Iteration
it=0;
while (it<=MaxIt)&&(FEs<=MaxFEs)
    it=it+1;

    Div(it)=diversity(Position,LB,UB);

    k = log(MaxIt - it)/log(MaxIt);
    E =(it/MaxIt)^(1/3);
    m1=E/10;
    m2=E/50;
    newX = Position;
    for i=1:N
        for j=1:dim
            % adaptive step size wandering strategy
            r1=rand();
            if r1 < k
                S1=(r1-(k/2))*k*(UB(j)-LB(j))/C;
                newX(i,j) = Position(i,j)+S1;
            end
            % absolute difference-based adaptive step size strategy
            r2=rand();
            if r2 < m1
                b = exp(cos(pi*(1-(1/it))));
                alpha1=5*(r2-m1/2)*cos(2*pi*r2)*exp(b);
                S2=alpha1*abs(Best_Pos(1,j)-Position(i,:));
                newX(i,:)= Best_Pos(1,j)+S2;
            end
            % boundary-based adaptive step size strategy
            r3=rand();
            if r3 < m2
                beta=10*pi*it/MaxIt;
                alpha2=r3*(r3-m2/2)*k*(1-it/MaxIt);
                S3=(UB(j)-LB(j))*cos(beta)*alpha2;
                newX(i,j)=Best_Pos(1,j)+S3;
            end
        end
    end

    for i=1:N
        % Coliision detection
        C_ub=newX(i,:)>UB;
        C_lb=newX(i,:)<LB;
        newX(i,:)=UB.*C_ub+LB.*C_lb+(newX(i,:).*(~(C_ub+C_lb)));

        newFitness(i) = fobj(newX(i,:));
        FEs=FEs+1;

        % Update
        if newFitness(i)<Fitness(i)
            Fitness(i) = newFitness(i);
            Position(i,:) = newX(i,:);
        end

        if newFitness(i) < Best_Score
            Best_Pos=newX(i,:);
            Best_Score=newFitness(i);
        end

        if rem(FEs,100)==0
            CG_curve=[CG_curve Best_Score];
            if size(CG_curve,2)>recordNum
                CG_curve=CG_curve(1:recordNum);
            end
        end

        if FEs>=MaxFEs; return; end
    end

    % Display iteration information
    % disp(['RRTO Iteration ' num2str(it) ': Best Fitness = ' num2str(Best_Score)]);

    if FEs>=MaxFEs; return; end

    if (it==MaxIt)&&(FEs<MaxFEs)
        it=it-1;
    end
end
end

%% Calculate the diversity of population
function div = diversity(X,LB,UB)
[N,~] = size(X);
ave_dim = mean(X);
L = 0.5 * (sum((UB - LB).^2)).^0.5;
div = 1 / (N * L) * sum((sum((X - repmat(ave_dim,[N,1])).^2,2)).^0.5);
end