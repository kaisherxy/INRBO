%======================================================================
% Improved Newton-Raphson-based optimizer with gap evolution strategy for multiple engineering problems
% Author: Xueyan Ru, Aimin Qiao, Kai He, Dawei Xue and Fan Yang
% Journal: Applied Mathematical Modelling
% E-mail: ruxy@bbc.edu.cn, xueyan_ru@sina.cn; kaihe@ustl.edu.cn, kaihe518@sina.cn
% SourceCode Developed by: Xueyan Ru and Kai He, 2025-08-29
%======================================================================

clc; clear; close all; warning('off');

addpath(genpath(cd));

for Func_name = [ 513 520 626 946 630]
    load (strcat('Results\TOC_f',num2str(Func_name)))
    load (strcat('Results\RDChOA_f',num2str(Func_name)))
    load (strcat('Results\RRTO_f',num2str(Func_name)))
    load (strcat('Results\NRBO_f',num2str(Func_name)))
    load (strcat('Results\INRBO_f',num2str(Func_name)))

    [FunName,dim,LB,UB,opt_f]=Get_Functions_details(Func_name);
    fprintf('\n***  f%d: %s, opt_f=%1.8E, dim=%d\n', Func_name, FunName, opt_f, dim);

    %% plot convergence curves
    % Here are some partial examples for reference.
    % The starting points are consistent because the initial solutions of all algorithms are controlled by a unified random seed.
    index=(0:size(TOC_CG_curve,2)-1)*100;
    figure('Name',strcat('Convergence_f',num2str(Func_name)))
    semilogy(index,mean(TOC_CG_curve),'-b');
    ylabel('log_{10}f(x)');
    xlabel('FEs');
    title(FunName);
    hold on
    semilogy(index,mean(RDChOA_CG_curve),'-m');
    semilogy(index,mean(RRTO_CG_curve),'-g');
    semilogy(index,mean(NRBO_CG_curve),'-K');
    semilogy(index,mean(INRBO_CG_curve),'-r');
    print(gcf,strcat('Results\Convergence_f',num2str(Func_name)),'-depsc','-r600')

    %% plot diversity
    if size(NRBO_Div,2) >= 1500
        index = 1500;
    else
        index = 500;
    end
    figure('Name',strcat('Diversity_f',num2str(Func_name)))
    plot(mean(NRBO_Div(:,1:index)),'-K');
    hold on;
    plot(mean(INRBO_Div(:,1:index)),'-r');
    xlabel('Iterations');
    ylabel('Population diversity');
    title(FunName);
    print(gcf,strcat('Results\Diversity_f',num2str(Func_name)),'-depsc','-r600')

    %% Wilcoxon signed rank test
    % Here are some partial examples for reference.
    [TOC_p,TOC_h,TOC_stats]=signrank(INRBO_Best_Score,TOC_Best_Score);
    fprintf(' f%d: INRBO vs TOC, p-value=%1.8E, significance level=%d\n', Func_name,TOC_p,TOC_h);
    [RDChOA_p,RDChOA_h,RDChOA_stats]=signrank(INRBO_Best_Score,RDChOA_Best_Score);
    fprintf(' f%d: INRBO vs RDChOA, p-value=%1.8E, significance level=%d\n', Func_name,RDChOA_p,RDChOA_h);
    [RRTO_p,RRTO_h,RRTO_stats]=signrank(INRBO_Best_Score,RRTO_Best_Score);
    fprintf(' f%d: INRBO vs RRTO, p-value=%1.8E, significance level=%d\n', Func_name,RRTO_p,RRTO_h);
    [NRBO_p,NRBO_h,NRBO_stats]=signrank(INRBO_Best_Score,NRBO_Best_Score);
    fprintf(' f%d: INRBO vs NRBO, p-value=%1.8E, significance level=%d\n', Func_name,NRBO_p,NRBO_h);
end
fprintf('\n Execution completed at %s. Good Luck...', datetime);