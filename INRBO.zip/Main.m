%======================================================================
% Improved Newton-Raphson-based optimizer with gap evolution strategy for multiple engineering problems
% Author: Xueyan Ru, Aimin Qiao, Kai He, Dawei Xue and Fan Yang
% Journal: Applied Mathematical Modelling
% E-mail: ruxy@bbc.edu.cn, xueyan_ru@sina.cn; kaihe@ustl.edu.cn, kaihe518@sina.cn
% SourceCode Developed by: Xueyan Ru and Kai He, 2025-08-29
%======================================================================

clc; clear; close all; warning('off');

addpath(genpath(cd));

if gcp('nocreate')~=0; delete(gcp('nocreate')); end

parpool('local');

Population=30; 
Runs = 30;
delete ('Results\log.txt')
diary ('Results\log.txt')

for Func_name =[1:12 21:32 513 520 626 946 630]
    % 1:12. CEC2022 dim10
    % 21:32 is CEC2022 dim20
    %% Multiple engineering problems
    % 513: WSN, case3
    % 520: UAV, case2
    % 626 and 630: Parameter Identification of PV Models, case1 and case1 (old)
    % 946: SOPWM for 5-level Inverters, case4

    % Load details of the selected benchmark function
    [FunName,dim,LB,UB,opt_f]=Get_Functions_details(Func_name);

    % Max number of function evaluations
    if 1 <= Func_name && Func_name <=12 && dim==10
        MaxFEs = 2*1E5;              % Max number of function evaluations for dim10 of CEC2022
    elseif 21 <= Func_name && Func_name <=32 && dim==20
        MaxFEs = 10*1E5;             % Max number of function evaluations for dim20 of CEC2022
    elseif 12<Func_name && dim<=30   % PV dim7, UAV dim30, SOPWM dim25
        MaxFEs = 2*1E5;
    else                              % WSN dim70
        MaxFEs = 2*1E4;
    end
    MaxIt = ceil(MaxFEs/Population);  % MaxIter: Max number of  iterations
    fprintf('\n***  f%d: %s, opt_f=%1.8E, Population=%d, dim=%d, MaxFEs=%d, Runs=%d\n', Func_name, FunName, opt_f, Population, dim, MaxFEs,Runs);
    fobj = @(x) GetFitness(x,Func_name);

    clear -regexp ^TOC ^RDChOA ^RRTO ^NRBO ^INRBO;
    %% Execute
    parfor r=1:Runs
        tic;
        [TOC_Best_Score(r,:),TOC_Best_Pos(r,:),TOC_CG_curve(r,:),TOC_Div(r,:)] = TOC(Population,MaxIt,LB,UB,dim,fobj,MaxFEs,Func_name,Runs,r);      % TOC
        TOC_Time(r)=toc;

        tic;
        [RDChOA_Best_Score(r,:),RDChOA_Best_Pos(r,:),RDChOA_CG_curve(r,:),RDChOA_Div(r,:)] = RDChOA(Population,MaxIt,LB,UB,dim,fobj,MaxFEs,Func_name,Runs,r);   % RDChOA
        RDChOA_Time(r)=toc;

        tic;
        [RRTO_Best_Score(r,:),RRTO_Best_Pos(r,:),RRTO_CG_curve(r,:),RRTO_Div(r,:)] = RRTO(Population,MaxIt,LB,UB,dim,fobj,MaxFEs,Func_name,Runs,r);     % RRTO
        RRTO_Time(r)=toc;

        tic;
        [NRBO_Best_Score(r,:),NRBO_Best_Pos(r,:),NRBO_CG_curve(r,:),NRBO_Div(r,:)] = NRBO(Population,MaxIt,LB,UB,dim,fobj,MaxFEs,Func_name,Runs,r);     % NRBO
        NRBO_Time(r)=toc;

        tic;
        [INRBO_Best_Score(r,:),INRBO_Best_Pos(r,:),INRBO_CG_curve(r,:),INRBO_Div(r,:)] = INRBO(Population,MaxIt,LB,UB,dim,fobj,MaxFEs,Func_name,Runs,r); % INRBO
        INRBO_Time(r)=toc;
    end

    % ===== Output Results =====
    fprintf('TOC_Mean= %1.8E,TOC_Std=%1.8E,TOC_Best=%1.8E; TOC_MeanTime= %1.2f,TOC_StdTime=%1.2f;\n',...
        mean(TOC_Best_Score), std(TOC_Best_Score), min(TOC_Best_Score), mean(TOC_Time), std(TOC_Time));
    save(strcat('Results\TOC_f',num2str(Func_name)),'TOC_Best_Score','TOC_Best_Pos','TOC_CG_curve','TOC_Div');

    fprintf('RDChOA_Mean= %1.8E,RDChOA_Std=%1.8E,RDChOA_Best=%1.8E; RDChOA_MeanTime= %1.2f,RDChOA_StdTime=%1.2f;\n',...
        mean(RDChOA_Best_Score), std(RDChOA_Best_Score), min(RDChOA_Best_Score), mean(RDChOA_Time), std(RDChOA_Time));
    save(strcat('Results\RDChOA_f',num2str(Func_name)),'RDChOA_Best_Score','RDChOA_Best_Pos','RDChOA_CG_curve','RDChOA_Div');

    fprintf('RRTO_Mean= %1.8E,RRTO_Std=%1.8E,RRTO_Best=%1.8E; RRTO_MeanTime= %1.2f,RRTO_StdTime=%1.2f;\n',...
        mean(RRTO_Best_Score), std(RRTO_Best_Score), min(RRTO_Best_Score), mean(RRTO_Time), std(RRTO_Time));
    save(strcat('Results\RRTO_f',num2str(Func_name)),'RRTO_Best_Score','RRTO_Best_Pos','RRTO_CG_curve','RRTO_Div');

    fprintf('NRBO_Mean= %1.8E,NRBO_Std=%1.8E,NRBO_Best=%1.8E; NRBO_MeanTime= %1.2f,NRBO_StdTime=%1.2f;\n',...
        mean(NRBO_Best_Score), std(NRBO_Best_Score), min(NRBO_Best_Score), mean(NRBO_Time), std(NRBO_Time));
    save(strcat('Results\NRBO_f',num2str(Func_name)),'NRBO_Best_Score','NRBO_Best_Pos','NRBO_CG_curve','NRBO_Div');

    fprintf('INRBO_Mean= %1.8E,INRBO_Std=%1.8E,INRBO_Best=%1.8E; INRBO_MeanTime= %1.2f,INRBO_StdTime=%1.2f;\n',...
        mean(INRBO_Best_Score), std(INRBO_Best_Score), min(INRBO_Best_Score), mean(INRBO_Time), std(INRBO_Time));
    save(strcat('Results\INRBO_f',num2str(Func_name)),'INRBO_Best_Score','INRBO_Best_Pos','INRBO_CG_curve','INRBO_Div');
end
diary off
fprintf('\n Execution completed at %s. Good Luck...', datetime);
if gcp('nocreate')~=0; delete(gcp('nocreate')); end