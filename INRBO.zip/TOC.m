% Reference paper: Tornado optimizer with Coriolis force: a novel bio-inspired meta-heuristic algorithm for solving engineering problems
% Journal:  Artificial Intelligence Review
% doi:10.1007/s10462-025-11118-9
% https://ww2.mathworks.cn/matlabcentral/fileexchange/180050-tornado-optimizer-with-coriolis-force-a-novel-bio-inspired

function [Best_Score, Best_Pos, CG_curve, Div] = TOC(N, MaxIt, LB, UB, dim, fobj, MaxFEs,Func_name,Runs,r)

global initial_flag
initial_flag = 0;
Div=Inf(1,MaxIt); 
recordNum=MaxFEs/100+1;

%% Default Values for TOC
nto=4;
nt =3;
FEs=0; 

%% Initialize Population and Evaluate Fitness
Position=zeros(N,dim);
Fitness = zeros(N, 1);
Rand_Seeds=load('input_data\Rand_Seeds.txt');
seed_ind=(dim*Func_name*Runs)/10-r-Runs;
seed_ind=mod(seed_ind,1000)+1;
run_seed=Rand_Seeds(seed_ind);
rng(run_seed,'twister');
for i=1:N
    Position(i,:)=LB+rand(1,dim).*(UB-LB);
    Fitness(i) = fobj(Position(i,:));
end
FEs = FEs + N;
rng('shuffle'); 

[~,index]=sort(Fitness) ;
Best_Score = Fitness(index(1));
Best_Pos = Position(index(1),:);

% Initialize convergence curve
CG_curve = Fitness(1);

%% Forming Windstorms, Thunderstorms, and Tornado of the Tornado Optimizer with Coriolis force (TOC)
% nto: Number of thunderstorms and tornadoes
% Nt : Number of thunderstorms
% To:  Number of tornadoes
% nw: number of windstorms

To= nto - nt;% Tornadoes
nw=N-nto; % Windstorms

%================ Forming and evaluating the population of the Tornadoes ================

%================ Forming and evaluating the population of the Thunderstorms ================
Thunderstormsposition(1:nto-1,:)=Position(index(2:nto),:);
ThunderstormsCost(1:nto-1)=Fitness(index(2:nto));

bThunderstormsCost = ThunderstormsCost;

bThunderstormsposition = Thunderstormsposition; % Initial best Thunderstorms position

%================ Forming and evaluating the population of the Windstorms ================

Windstormsposition(1:nw,:)=Position(index(nto+1:nto+nw),:) ;
WindstormsCost(1:nw)=Fitness(index(nto+1:nto+nw)) ;

bWindstormsCost = WindstormsCost;
bWindstormsposition = Windstormsposition; % % Initial best windstorms position (Update the best positions of windstorms)

%% Velcity term of TOC
vel_storm = 0.1*Windstormsposition; % Velocity of windstorms

%%  Designate windstorms to thunderstorms and Tornadoes
nwindstorms=1:nw;
nwindstorms=nwindstorms(sort(randperm(nw,nto)));

% Combining windstorms to tornado

nWT=diff(nwindstorms)';
nWT(end+1)= nw-sum(nWT);
% nWT1=sort(nWT1,'descend');

nWT1 = nWT(1);

% Combining windstorms to thunderstorms

nWH=nWT(2:end);

%% Parameter setting s for TOC
b_r=100000;
fdelta=[-1,1];

%% Key functions of Tornado Optimizer with Coriolis force (TOC)
chi=4.10;
eta=2/abs(2-chi-sqrt(chi^2-4*chi)) ;
%% Iteration
it=0;
while (it<=MaxIt)&&(FEs<=MaxFEs)
    it=it+1;

    X1=[Best_Pos;Thunderstormsposition;Windstormsposition];
    Div(it)=diversity(X1,LB,UB);

    %% Key adaptive functions (Adaptive parameters) of TOC
    nu  =(0.1*exp(-0.1*(it/MaxIt)^0.1))^16;
    mu = 0.5 + rand/2;
    ay=(MaxIt-(it^2/MaxIt))/MaxIt ;

    Rl = 2/(1+exp((-it+MaxIt/2)/2)) ;
    Rr = -2/(1+exp((-it+MaxIt/2)/2)) ;

    %%  Evolution of windstorms to Tornadoes
    % Update velocity
    for i=1:nw
        for j = 1:dim
            if rand > 0.5

                delta1=fdelta(ceil(2*rand()));
                zeta=ceil((To).*rand(1,To))'; %

                wmin=1;
                wmax=4.0;
                rr=wmin+rand()*(wmax-wmin);
                wr= (((2*rand()) - (1*rand()+rand()))/rr);

                c=b_r*delta1*wr;

                omega = 0.7292115E-04;
                %            w_r = sin(-1 + 2.*rand(1,1));
                f= 2*omega*sin(-1 + 2.*rand(1,1));

                phi(i,j) = Best_Pos(zeta,j) - Windstormsposition(i,j);

                if sign(Rl)>=0
                    if sign(phi(i,j))>=0
                        phi(i,j) = -phi(i,j);
                    end
                end

                CFl =(((f^2*Rl^2)/4) -Rl* 1 *phi(i,j));

                if sign(CFl)< 0
                    CFl= -CFl;
                end

                vel_storm(i,j)= eta*  (mu*vel_storm(i,j) - c* (f*Rl)/2 +(sqrt(CFl)));

            else

                delta1=fdelta(ceil(2*rand()));
                zeta=ceil((To).*rand(1,To))'; %

                rmin=1; rmax=4.0; rr=rmin+rand()*(rmax-rmin);
                wr= (((2*rand()) - (1*rand()+rand()))/rr);
                c=b_r*delta1*wr;

                phi(i,j) = Best_Pos (zeta,j)-Windstormsposition(i,j);

                if sign(Rr)<=0
                    if sign(phi(i,j))<=0
                        phi(i,j) = -phi(i,j);
                    end
                end

                omega =0.7292115E-04;% s�1
                %          w_r = sin(-1 + 2.*rand(1,1));
                f= 2*omega*sin(-1 + 2.*rand(1,1));

                CFr =(((f^2*Rr^2)/4) -Rr* 1 *phi(i,j));

                if sign(CFr)<0
                    CFr= -CFr;
                end

                vel_storm(i,j)= eta  *(mu* vel_storm(i,j) - c* (f*Rr)/2 +(sqrt(CFr)))  ;
            end
        end

    end

    %% %% Exploration - Evolution of windstorms to Tornadoes
    for i=1:nWT1
        rand_index = floor((nWT1).*rand(1,nWT1))+1;
        rand_w = Windstormsposition(rand_index, :);

        alpha=abs(2*ay*rand-1*rand)   ;

        Windstormsposition(i,:)=Windstormsposition(i,:)+2*alpha*(Best_Pos  - rand_w(i,:)) + vel_storm(i,:);

        ub_=Windstormsposition(i,:)>UB;
        lb_=Windstormsposition(i,:)<LB;
        Windstormsposition(i,:)=(Windstormsposition(i,:).*(~(ub_+lb_)))+UB.*ub_+LB.*lb_;

        WindstormsCost(i) = fobj(Windstormsposition(i,:));
        FEs=FEs+1;

        % Finding out the best positions
        if WindstormsCost(i)<bWindstormsCost(i)
            bWindstormsposition(i,:)=Windstormsposition(i,:) ; % Best solutions
            bWindstormsCost(i)=WindstormsCost(i);   % Best cost
        end

        if WindstormsCost(i) < Best_Score
            Best_Pos=Windstormsposition(i,:);
            Best_Score=WindstormsCost(i);
        end
        if rem(FEs,100)==0
            CG_curve=[CG_curve Best_Score];
            if size(CG_curve,2)>recordNum
                CG_curve=CG_curve(1:recordNum);
            end
        end
        if FEs>=MaxFEs; return; end
    end

    %% ================ Exploitation -  Evolution of windstorms to thunderstorms ================
    %% ================  Combining windstorms together to form thunderstorms ================
    for i=1:nt
        for j=1:nWH(i)
            rand_index = floor((nt).*rand(nt))+1;
            rand_w = Windstormsposition(rand_index, :);

            c1=abs(2*ay*rand-1*ay);

            c2=abs(ay - 2*ay*rand);

            Windstormsposition((j+sum(nWT(1:i))),:)=Windstormsposition((j+sum(nWT(1:i))),:)+2*rand*(Thunderstormsposition(i,:)-Windstormsposition((j+sum(nWT(1:i))),:))+...
                + 2*rand*(Best_Pos (1,:)-Windstormsposition((j+sum(nWT(1:i))),:));

            ub_=Windstormsposition((j+sum(nWT(1:i))),:)>UB;
            lb_=Windstormsposition((j+sum(nWT(1:i))),:)<LB;
            Windstormsposition((j+sum(nWT(1:i))),:)=(Windstormsposition((j+sum(nWT(1:i))),:).*(~(ub_+lb_)))+UB.*ub_+LB.*lb_;

            WindstormsCost((j+sum(nWT(1:i)))) = fobj(Windstormsposition((j+sum(nWT(1:i))),:));
            FEs=FEs+1;

            if WindstormsCost((j+sum(nWT(1:i))))<ThunderstormsCost(i)
                bThunderstormsposition(i,:) =Windstormsposition((j+sum(nWT(1:i))),:);
                Thunderstormsposition(i,:)=Windstormsposition((j+sum(nWT(1:i))),:);
                ThunderstormsCost(i)=WindstormsCost((j+sum(nWT(1:i))));
            end

            if WindstormsCost(i) < Best_Score
                Best_Pos=Windstormsposition(i,:);
                Best_Score=WindstormsCost(i);
            end

            if rem(FEs,100)==0
                CG_curve=[CG_curve Best_Score];
                if size(CG_curve,2)>recordNum
                    CG_curve=CG_curve(1:recordNum);
                end
            end

            if FEs>=MaxFEs; return; end
        end
    end

    %% ================  Evolution of thunderstorms to tornado ================
    for i=1:nt
        zeta=ceil((To).*rand(1,To)); %
        alpha=abs(2*ay*rand-1*rand);
        p = floor((nt).*rand(1,nt))+1;
        rand_w = Thunderstormsposition(p, :);

        Thunderstormsposition(i,:)=Thunderstormsposition(i,:)+2.*alpha*(Thunderstormsposition(i,:) - Best_Pos(zeta,:))+...
            +2.*alpha*(rand_w(i,:) - Thunderstormsposition(i,:));

        ub_=Thunderstormsposition(i,:)>UB;
        lb_=Thunderstormsposition(i,:)<LB;
        Thunderstormsposition(i,:)=(Thunderstormsposition(i,:).*(~(ub_+lb_)))+UB.*ub_+LB.*lb_;

        ThunderstormsCost(i) = fobj(Thunderstormsposition(i,:));
        FEs=FEs+1;

        if ThunderstormsCost(i)<bThunderstormsCost(i)
            bThunderstormsposition(i,:) =Thunderstormsposition(i,:);
            bThunderstormsCost(i) =ThunderstormsCost(i);
        end

        if ThunderstormsCost(i) < Best_Score
            Best_Pos=Thunderstormsposition(i,:);
            Best_Score=ThunderstormsCost(i);
        end
        if rem(FEs,100)==0
            CG_curve=[CG_curve Best_Score];
            if size(CG_curve,2)>recordNum
                CG_curve=CG_curve(1:recordNum);
            end
        end
        if FEs>=MaxFEs; return; end
    end

    %%   ================  Random formation of windstorms, tornadoes and thunderstorms ================
    % Check windstorms formation for windstorms and tornadoes
    for i=1:nWT1
        if  ((norm(Windstormsposition(i,:)-Best_Pos)<nu))
            delta2=fdelta(floor(2*rand()+1));
            Windstormsposition(i,:)=  Windstormsposition(i,:) - (2*ay*(rand*(LB-UB) - LB))*delta2;
        end
    end

    % Check windstorms formation for windstorms and thunderstorms
    for i=1:nt
        if  ((norm(Windstormsposition(i,:)-Thunderstormsposition(i,:))<nu))
            for j=1:nWH(i)
                delta2=fdelta(floor(2*rand()+1)) ;
                Windstormsposition((j+ sum(nWT(1:i))),:)=  Windstormsposition((j+ sum(nWT(1:i))),:) - (2*ay*(rand*(LB-UB) - LB))*delta2;
            end
        end
    end

    % Display iteration information
    % disp(['TOC Iteration ' num2str(it) ': Best Fitness = ' num2str(Best_Score)]);

    if FEs>=MaxFEs; return; end

    if (it==MaxIt)&&(FEs<MaxFEs)
        it=it-1;
    end
end
end

%% Calculate the diversity of population
function div = diversity(X,LB,UB)
[N,~] = size(X);
ave_dim = mean(X);
L = 0.5 * (sum((UB - LB).^2)).^0.5;
div = 1 / (N * L) * sum((sum((X - repmat(ave_dim,[N,1])).^2,2)).^0.5);
end
