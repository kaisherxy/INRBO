function ObjVal= GetFitness(X, FunIndex)

global initial_flag
persistent model
[ps,D]=size(X);
switch(FunIndex)

    %% FunIndex: 1-12-->CEC2022
    case num2cell(1:12)
        ObjVal=cec22_test_func(X',FunIndex);

    case num2cell(21:32)
        FunIndex = FunIndex -20;
        ObjVal=cec22_test_func(X',FunIndex);

        %% WSN (2D)
    case 513
        L = 50;
        m = 0:1:L;
        p=[reshape(repmat(m,length(m),1),length(m)^2,1) reshape(repmat(m',length(m),1),length(m)^2,1)];
        x = X(1:2:end);
        y = X(2:2:end);
        Rs = 5;
        num=size(p, 1);
        C= ones(num,length(x));
        A = sqrt((p(:, 1)-x.*ones(num,1)).^2+(p(:, 2)-y.*ones(num,1)).^2);
        C(Rs >=A)=0;
        P = 1-prod(C,2);
        ObjVal = 1-sum(P)/num;

        %% Safety-enhanced UAV Path Planning
    case 520
        if initial_flag == 0
            model = CreateModel();
            initial_flag = 1;
        end

        xs = model.start(1);
        ys = model.start(2);
        zs = model.start(3);

        r = X(:,1:10);
        psi = X(:,11:20);
        phi = X(:,21:30);
        x=zeros(1,model.n);y=x;z=x;

        x(1) = xs + r(1)*cos(psi(1))*sin(phi(1));
        x(1)=min(max(x(1),model.xmin),model.xmax);

        y(1) = ys + r(1)*cos(psi(1))*cos(phi(1));
        y(1)=min(max(y(1),model.ymin),model.ymax);

        z(1) = zs + r(1)*sin(psi(1));
        z(1)=min(max(z(1),model.zmin),model.zmax);

        for i = 2:model.n
            x(i) = x(i-1) + r(i)*cos(psi(i))*sin(phi(i));
            x(i)=min(max(x(i),model.xmin),model.xmax);

            y(i) = y(i-1) + r(i)*cos(psi(i))*cos(phi(i));
            y(i)=min(max(y(i),model.ymin),model.ymax);

            z(i) = z(i-1) + r(i)*sin(psi(i));
            z(i)=min(max(z(i),model.zmin),model.zmax);
        end

        sol.x = x;
        sol.y = y;
        sol.z = z;
        ObjVal=Path_Cost(sol,model);

        %% Schutten Solar STP6-120/36 Polycrystalline Photovoltaic Model (DDM) at 1000W/m² and 55°C
    case 626
        V_L = [19.21,17.65,17.41,17.25,17.10,16.90,16.76,16.34,16.08,15.71,15.39,14.93,14.58,14.17,13.59,13.16,12.74,12.36,11.81,11.17,10.32,9.740,9.060,0];
        I_L = [0,3.83,4.29,4.56, 4.79, 5.07, 5.27, 5.75, 6.00, 6.36, 6.58, 6.83, 6.97, 7.10, 7.23, 7.29, 7.34, 7.37, 7.38, 7.41, 7.44, 7.42, 7.45,7.48];
        ObjVal = Calculate_RMSE(X, 36, 1, 55, V_L, I_L);

        %% Schutten Solar STM6-40/36 Monocrystalline Photovoltaic Model (DDM) at 1000W/m² and 51°C
    case{630}
        V_L = [0,0.118,2.237,5.434,7.260,9.680,11.59,12.60,13.37,14.09,14.88,15.59,16.40,16.71,16.98,17.13,17.32,17.91,19.08,21.02];
        I_L = [1.663,1.663,1.661,1.653,1.650,1.645,1.640,1.636,1.629,1.619,1.597,1.581,1.542,1.524,1.500,1.485,1.465,1.388,1.118,0];

        ObjVal = Calculate_RMSE(X, 36, 1, 51, V_L, I_L);

        %% SOPWM for 5-level Inverters
    case 946
        m = 0.32;
        s = [1,-1,1,1,-1,1,-1,1,-1,-1,1,-1,1,1,-1,1,-1,1,-1,-1,1,-1,1,1,-1];
        k = [5,7,11,13,17,19,23,25,29,31,35,37,41,43,47,49,53,55,59,61,65,67,71,73,77,79,83,85,91,95,97];
        for i = 1:ps
            su = 0;
            for j = 1:31
                su2 = 0;
                for l = 1:D
                    su2 = su2 + s(l).*cos(k(j).*X(i,l)*pi/180);
                end
                su = su + su2.^2./k(j).^4;
            end
            ObjVal(i,1) = 0.5.*(su).^0.5./(sum(1./k.^4)).^0.5;
        end
        g = zeros(ps,D-1);
        for i = 1:D-1
            g(:,i) = X(:,i)-X(:,i+1)+1e-6;
        end
        h = sum(s.*cos(X*pi/180),2)-2*m;
        penalty_coef=0.1;
        epsilon=0.0001;
        g = max(g, 0);
        h = max(abs(h) - epsilon, 0);
        g_violation=sum(g, 2);
        h_violation=sum(h, 2);
        ObjVal = ObjVal+penalty_coef*g_violation+penalty_coef*h_violation;
end
end

function  Rmse_Out= Calculate_RMSE(X,Ns,Np,temperature,V_L,I_L)
q = 1.60217646e-19;
k = 1.3806503e-23;
T = 273.15+temperature;
V_t  = k*T/q;

I_ph = X(1);
row = size(V_L, 2);
sum1 = 0;

I_sd1 = X(2); I_sd2 = X(3); R_s = X(4); R_sh  = X(5); A1 = X(6); A2 = X(7);
for i=1:row
    y1 = I_ph*Np-I_sd1*Np*(exp((V_L(i)/Ns+R_s*I_L(i)/Np)/(A1*V_t))-1)-I_sd2*Np*(exp((V_L(i)/Ns+R_s*I_L(i)/Np)/(A2*V_t))-1)-...
        (V_L(i)/Ns+R_s*I_L(i)/Np)/(R_sh/Np)-I_L(i);
    sum1 = sum1+y1*y1;

    Rmse_Out = sqrt(sum1/row);
end
end

% ------------------------------------------- %
% This is the source code for the algorithm Spherical Vector-based Particle Swarm Optimization (SPSO).
% The current implementation is for path planning of Unmanned Aerial Vehicles (UAV).
% Details can be found in the paper:
% Manh Duong Phung, Quang Phuc Ha, "Safety-enhanced UAV Path Planning with Spherical Vector-based Particle Swarm Optimization",
% Journal of Applied soft computing, vol. 107, pp. 107376, 2021.
% Link to the paper: https://doi.org/10.1016/j.asoc.2021.107376
% The program may require installing the Curve Fitting Toolbox depending on your MATLAB version.
function model=CreateModel()
H = imread('input_data/ChrismasTerrain.tif');
H (H < 0) = 0;
MAPSIZE_X = size(H,2);
MAPSIZE_Y = size(H,1);
[X,Y] = meshgrid(1:MAPSIZE_X,1:MAPSIZE_Y);

R1=80;
x1 = 400; y1 = 500; z1 = 100;

R2=70;
x2 = 600; y2 = 200; z2 = 150;

R3=80;
x3 = 500; y3 = 350; z3 = 150;

R4=70;
x4 = 350; y4 = 200; z4 = 150;

R5=70;
x5 = 700; y5 = 550; z5 = 150;

R6=80;
x6 = 650; y6 = 750; z6 = 150;

xmin= 1;
xmax= MAPSIZE_X;

ymin= 1;
ymax= MAPSIZE_Y;

zmin = 100;
zmax = 200;

start_location = [200;100;150];
end_location = [800;800;150];

n=10;

model.start=start_location;
model.end=end_location;
model.n=n;
model.xmin=xmin;
model.xmax=xmax;
model.zmin=zmin;
model.ymin=ymin;
model.ymax=ymax;
model.zmax=zmax;
model.MAPSIZE_X = MAPSIZE_X;
model.MAPSIZE_Y = MAPSIZE_Y;
model.X = X;
model.Y = Y;
model.H = H;
model.threats = [x1 y1 z1 R1;x2 y2 z2 R2; x3 y3 z3 R3; x4 y4 z4 R4; x5 y5 z5 R5;x6 y6 z6 R6];
end

function ObjVal=Path_Cost(sol,model)
J_inf = inf;
n = model.n;
H = model.H;

x=sol.x;
y=sol.y;
z=sol.z;

xs=model.start(1);
ys=model.start(2);
zs=model.start(3);

xf=model.end(1);
yf=model.end(2);
zf=model.end(3);
x_all = [xs x xf];
y_all = [ys y yf];
z_all = [zs z zf];
N = size(x_all,2);

z_abs = zeros(1,N);
for i = 1:N
    z_abs(i) = z_all(i) + H(round(y_all(i)),round(x_all(i)));
end

J1 = 0;
for i = 1:N-1
    diff = [x_all(i+1) - x_all(i);y_all(i+1) - y_all(i);z_abs(i+1) - z_abs(i)];
    J1 = J1 + norm(diff);
end


threats = model.threats;
threat_num = size(threats,1);

drone_size = 1;
danger_dist = 10*drone_size;

J2 = 0;
for i = 1:threat_num
    threat = threats(i,:);
    threat_x = threat(1);
    threat_y = threat(2);
    threat_radius = threat(4);
    for j = 1:N-1
        dist = DistP2S([threat_x threat_y],[x_all(j) y_all(j)],[x_all(j+1) y_all(j+1)]);
        if dist > (threat_radius + drone_size + danger_dist)
            threat_cost = 0;
        elseif dist < (threat_radius + drone_size)
            threat_cost = J_inf;
        else
            threat_cost = (threat_radius + drone_size + danger_dist) - dist;
        end
        J2 = J2 + threat_cost;
    end
end

zmax = model.zmax;
zmin = model.zmin;
J3 = 0;
for i=1:n
    if z(i) < 0
        J3_node = J_inf;
    else
        J3_node = abs(z(i) - (zmax + zmin)/2);
    end
    J3 = J3 + J3_node;
end

J4 = 0;
turning_max = 45;
climb_max = 45;
for i = 1:N-2
    for j = i:-1:1
        segment1_proj = [x_all(j+1); y_all(j+1); 0] - [x_all(j); y_all(j); 0];
        if nnz(segment1_proj) ~= 0
            break;
        end
    end

    for j = i:N-2
        segment2_proj = [x_all(j+2); y_all(j+2); 0] - [x_all(j+1); y_all(j+1); 0];
        if nnz(segment2_proj) ~= 0
            break;
        end
    end

    climb_angle1 = atan2d(z_abs(i+1) - z_abs(i),norm(segment1_proj));
    climb_angle2 = atan2d(z_abs(i+2) - z_abs(i+1),norm(segment2_proj));
    turning_angle = atan2d(norm(cross(segment1_proj,segment2_proj)),dot(segment1_proj,segment2_proj));

    if abs(turning_angle) > turning_max
        J4 = J4 + abs(turning_angle);
    end
    if abs(climb_angle2 - climb_angle1) > climb_max
        J4 = J4 + abs(climb_angle2 - climb_angle1);
    end
end

b1 = 5;
b2 = 1;
b3 = 10;
b4 = 1;

ObjVal = b1*J1 + b2*J2 + b3*J3 + b4*J4;
end

function dist = DistP2S(x,a,b)
d_ab = norm(a-b);
d_ax = norm(a-x);
d_bx = norm(b-x);
if d_ab ~= 0
    if dot(a-b,x-b)*dot(b-a,x-a)>=0
        A = [b-a;x-a];
        dist = abs(det(A))/d_ab;
    else
        dist = min(d_ax, d_bx);
    end
else
    dist = d_ax;
end
end
% ------------------------------------------- %
