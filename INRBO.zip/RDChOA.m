% Software defect prediction based on support vector machine optimized by reverse differential chimp optimization algorithm
% Authors: L.-F. Chen, S.-P. Zhang, Y.-Y. Qin, K.-X. Cao, T. Du and Q. Dai
% Journal: International Journal of Data Science and Analytics 2025
% DOI: https://doi.org/10.1007/s41060-025-00726-x
% https://ww2.mathworks.cn/matlabcentral/fileexchange/180358-rdchoa

function [Best_Score, Best_Pos, CG_curve, Div]=RDChOA(N, MaxIt, LB, UB, dim, fobj, MaxFEs,Func_name,Runs,r)

global initial_flag
initial_flag = 0;
Div=Inf(1,MaxIt);   
FEs=0;                 
recordNum=MaxFEs/100+1; 

%% Initialize Population and Evaluate Fitness
Position=zeros(N,dim);
Fitness = zeros(N, 1); 
Rand_Seeds=load('input_data\Rand_Seeds.txt');
seed_ind=(dim*Func_name*Runs)/10-r-Runs;
seed_ind=mod(seed_ind,1000)+1;
run_seed=Rand_Seeds(seed_ind);
rng(run_seed,'twister');
for i=1:N
    Position(i,:)=LB+rand(1,dim).*(UB-LB);
    Fitness(i) = fobj(Position(i,:));
end
FEs = FEs + N;
rng('shuffle');

[~, Ind] = sort(Fitness);
Best_Score = Fitness(Ind(1));
Best_Pos = Position(Ind(1),:);

% initialize Attacker, Barrier, Chaser, and Driver
Attacker_pos=zeros(1,dim);
Attacker_score=inf; %change this to -inf for maximization problems

Barrier_pos=zeros(1,dim);
Barrier_score=inf; %change this to -inf for maximization problems

Chaser_pos=zeros(1,dim);
Chaser_score=inf; %change this to -inf for maximization problems

Driver_pos=zeros(1,dim);
Driver_score=inf; %change this to -inf for maximization problems

% Initialize convergence curve
CG_curve = Fitness(1);

%% Iteration
it=0;
while (it<=MaxIt)&&(FEs<=MaxFEs)
    it=it+1;

    Div(it)=diversity(Position,LB,UB);

    for i=1:size(Position,1)
        % Return back the search agents that go beyond the boundaries of the search space
        Flag4ub=Position(i,:)>UB;
        Flag4lb=Position(i,:)<LB;
        Position(i,:)=(Position(i,:).*(~(Flag4ub+Flag4lb)))+UB.*Flag4ub+LB.*Flag4lb;

        % Calculate objective function for each search agent
        fitness = fobj(Position(i,:));
        FEs=FEs+1;

        % Update Attacker, Barrier, Chaser, and Driver
        if fitness<Attacker_score
            Attacker_score=fitness; % Update Attacker
            Attacker_pos=Position(i,:);
        end

        if fitness>Attacker_score && fitness<Barrier_score
            Barrier_score=fitness; % Update Barrier
            Barrier_pos=Position(i,:);
        end

        if fitness>Attacker_score && fitness>Barrier_score && fitness<Chaser_score
            Chaser_score=fitness; % Update Chaser
            Chaser_pos=Position(i,:);
        end
        if fitness>Attacker_score && fitness>Barrier_score && fitness>Chaser_score && fitness>Driver_score
            Driver_score=fitness; % Update Driver
            Driver_pos=Position(i,:);
        end

        if fitness < Best_Score
            Best_Pos=Position(i,:);
            Best_Score=fitness;
        end
        if rem(FEs,100)==0
            CG_curve=[CG_curve Best_Score];
            if size(CG_curve,2)>recordNum
                CG_curve=CG_curve(1:recordNum);
            end
        end
        if FEs>=MaxFEs; return; end
    end

    f=2-it*((2)/MaxIt); % a decreases linearly fron 2 to 0

    %  The Dynamic Coefficient of f Vector as Table 1.

    %Group 1
    C1G1=1.95-((2*it^(1/3))/(MaxIt^(1/3)));
    C2G1=(2*it^(1/3))/(MaxIt^(1/3))+0.5;

    %Group 2
    C1G2= 1.95-((2*it^(1/3))/(MaxIt^(1/3)));
    C2G2=(2*(it^3)/(MaxIt^3))+0.5;

    %Group 3
    C1G3=(-2*(it^3)/(MaxIt^3))+2.5;
    C2G3=(2*it^(1/3))/(MaxIt^(1/3))+0.5;

    %Group 4
    C1G4=(-2*(it^3)/(MaxIt^3))+2.5;
    C2G4=(2*(it^3)/(MaxIt^3))+0.5;

    k_rand=rand(1,1);
    k = (1+k_rand*((2*it)/MaxIt)^(0.5))^9;
    new_Attacker_pos = (LB+UB)/2+(LB+UB)/(2*k)-Attacker_pos/k;

    Flag4ub = new_Attacker_pos > UB;
    Flag4lb = new_Attacker_pos < LB;
    new_Attacker_pos = (new_Attacker_pos.*(~(Flag4ub+Flag4lb)))+UB.*Flag4ub+LB.*Flag4lb;

    fit_new_Attacker = fobj(new_Attacker_pos);
    FEs=FEs+1;

    if fit_new_Attacker < Attacker_score
        Attacker_pos = new_Attacker_pos;
        Attacker_score = fit_new_Attacker;
    end
    if fit_new_Attacker < Best_Score
        Best_Pos=new_Attacker_pos;
        Best_Score=fit_new_Attacker;
    end
    if rem(FEs,100)==0
        CG_curve=[CG_curve Best_Score];
        if size(CG_curve,2)>recordNum
            CG_curve=CG_curve(1:recordNum);
        end
    end
    if FEs>=MaxFEs; return; end

    % Update the Position of search agents including omegas
    for i=1:size(Position,1)
        for j=1:size(Position,2)
            %% Please note that to choose a other groups you should use the related group strategies
            r11=C1G1*rand(); % r1 is a random number in [0,1]
            r12=C2G1*rand(); % r2 is a random number in [0,1]

            r21=C1G2*rand(); % r1 is a random number in [0,1]
            r22=C2G2*rand(); % r2 is a random number in [0,1]

            r31=C1G3*rand(); % r1 is a random number in [0,1]
            r32=C2G3*rand(); % r2 is a random number in [0,1]

            r41=C1G4*rand(); % r1 is a random number in [0,1]
            r42=C2G4*rand(); % r2 is a random number in [0,1]

            A1=2*f*r11-f; % Equation (3)
            C1=2*r12; % Equation (4)

            %% % Please note that to choose various Chaotic maps you should use the related Chaotic maps strategies
            m=chaos(3,1,1); % Equation (5)
            D_Attacker=abs(C1*Attacker_pos(j)-m*Position(i,j)); % Equation (6)
            X1=Attacker_pos(j)-A1*D_Attacker; % Equation (7)

            A2=2*f*r21-f; % Equation (3)
            C2=2*r22; % Equation (4)

            D_Barrier=abs(C2*Barrier_pos(j)-m*Position(i,j)); % Equation (6)
            X2=Barrier_pos(j)-A2*D_Barrier; % Equation (7)

            A3=2*f*r31-f; % Equation (3)
            C3=2*r32; % Equation (4)

            D_Driver=abs(C3*Chaser_pos(j)-m*Position(i,j)); % Equation (6)
            X3=Chaser_pos(j)-A3*D_Driver; % Equation (7)

            A4=2*f*r41-f; % Equation (3)
            C4=2*r42; % Equation (4)

            D_Driver=abs(C4*Driver_pos(j)-m*Position(i,j)); % Equation (6)
            X4=Chaser_pos(j)-A4*D_Driver; % Equation (7)

            round_i=randi([1 i]);
            round_i=floor(round_i);
            round_j=randi([1 j]);
            round_j=floor(round_j);
            f1 = randn(1,1);
            f2 = randn(1,1);
            if i>(MaxIt/2) && j>(MaxIt/2)
                Position(i,j)=f1*(X1-Position(i,j-1))+f2*(Position(round_i,round_j)-Position(i,j-1));
            else
                Position(i,j)=(X1+X2+X3+X4)/4;
                % Positions(i,j)=1./(W1+W2+W3+W4).*(W1.*X1+W2.*X2+W3.*X3+W4.*X4)/4;
            end
        end
    end

    % Display iteration information
    % disp(['RDChOA Iteration ' num2str(it) ': Best Fitness = ' num2str(Best_Score)]);

    if FEs>=MaxFEs; return; end

    if (it==MaxIt)&&(FEs<MaxFEs)
        it=it-1;
    end
end
end

%% Calculate the diversity of population
function div = diversity(X,LB,UB)
[N,~] = size(X);
ave_dim = mean(X);
L = 0.5 * (sum((UB - LB).^2)).^0.5;
div = 1 / (N * L) * sum((sum((X - repmat(ave_dim,[N,1])).^2,2)).^0.5);
end

%% CHAOS METHOD
function O = chaos(index, max_iter, Value)
x = zeros(max_iter+1, 1);
G = zeros(max_iter, 1);
x(1) = 0.7;
switch index
    case 1 % ChebyshevMap
        for i = 1 : max_iter
            x(i+1) = cos(i*acos(x(i)));
            G(i)   = ((x(i)+1)*Value)/2;
        end
    case 2 % CircleMap
        a = 0.5;
        b = 0.2;
        for i = 1 : max_iter
            x(i+1) = mod(x(i)+b-(a/(2*pi))*sin(2*pi*x(i)), 1);
            G(i)   = x(i)*Value;
        end
    case 3 % Gauss/MouseMap
        for i = 1 : max_iter
            if x(i) == 0
                x(i+1) = 0;
            else
                x(i+1) = mod(1/x(i), 1);
            end
            G(i) = x(i)*Value;
        end
    case 4 % IterativeMap
        a = 0.7;
        for i = 1 : max_iter
            x(i+1) = sin((a*pi)/x(i));
            G(i)   = ((x(i)+1)*Value)/2;
        end
    case 5 % LogisticMap
        a = 4;
        for i = 1 : max_iter
            x(i+1) = a*x(i)*(1-x(i));
            G(i)   = x(i)*Value;
        end
    case 6 % PiecewiseMap
        P = 0.4;
        for i = 1 : max_iter
            if x(i) >= 0 && x(i) < P
                x(i+1) = x(i)/P;
            end
            if x(i) >= P && x(i) < 0.5
                x(i+1) = (x(i)-P)/(0.5-P);
            end
            if x(i) >= 0.5 && x(i) < 1-P
                x(i+1) = (1-P-x(i))/(0.5-P);
            end
            if x(i) >= 1-P && x(i) < 1
                x(i+1) = (1-x(i))/P;
            end
            G(i) = x(i)*Value;
        end
    case 7 %SineMap
        for i = 1 : max_iter
            x(i+1) = sin(pi*x(i));
            G(i)   = (x(i))*Value;
        end
    case 8 % SingerMap
        u = 1.07;
        for i = 1 : max_iter
            x(i+1) = u*(7.86*x(i)-23.31*(x(i)^2)+28.75*(x(i)^3)-13.302875*(x(i)^4));
            G(i)   = (x(i))*Value;
        end
    case 9 % SinusoidalMap
        for i = 1 : max_iter
            x(i+1) = 2.3*x(i)^2*sin(pi*x(i));
            G(i)   = (x(i))*Value;
        end
    case 10 % TentMap
        x(1) = 0.6;
        for i = 1 : max_iter
            if x(i) < 0.7
                x(i+1) = x(i)/0.7;
            end
            if x(i) >= 0.7
                x(i+1) = (10/3)*(1-x(i));
            end
            G(i) = (x(i))*Value;
        end
end
O = G;
end