function [FunName,Dim,LB,UB,opt_f] = Get_Functions_details(FunIndex)
if 1<= FunIndex && FunIndex <=12
    Dim = 10;
elseif 21<= FunIndex && FunIndex <=32
    Dim = 20;
end
opt_f=0;
% err=1e-8;   % Admissible error
FunName='';

switch(FunIndex)
    % FunIndex from 1 to 12 are CEC2022 functions
    %% FunIndex: 1-12-->CEC2022
    % Unimodal Function
    case {1,21}
        FunName='Shifted and full Rotated Zakharov Function';
        lb = -100; ub = 100;
        opt_f = 300;

        % Multimodal Functions
    case {2,22}
        FunName='Shifted and full Rotated Rosenbrock’s Function';
        lb = -100; ub = 100;
        opt_f = 400;
    case {3,23}
        FunName='Shifted and full Rotated Expanded Scaffer’s F6 Function';
        lb = -100; ub = 100;
        opt_f = 600;
    case {4,24}
        FunName='Shifted and full Rotated Non-Continuous Rastrigin’s Function';
        lb = -100; ub = 100;
        opt_f = 800;
    case {5,25}
        FunName='Shifted and full Rotated Lévy Function';
        lb = -100; ub = 100;
        opt_f = 900;

        % Hybrid Functions
    case {6,26}
        FunName='Hybrid Function 1 (N=3)';
        lb = -100; ub = 100;
        opt_f = 1800;
    case {7,27}
        FunName='Hybrid Function 2 (N=6)';
        lb = -100; ub = 100;
        opt_f = 2000;
    case {8,28}
        FunName='Hybrid Function 3 (N=5)';
        lb = -100; ub = 100;
        opt_f = 2200;

        % Composition Functions
    case {9,29}
        FunName='Composition Function 1 (N=5)';
        lb = -100; ub = 100;
        opt_f = 2300;
    case {10,30}
        FunName=' Composition Function 2 (N=4)';
        lb = -100; ub = 100;
        opt_f = 2400;
    case {11,31}
        FunName='Composition Function 3 (N=5)';
        lb = -100; ub = 100;
        opt_f = 2600;
    case {12,32}
        FunName='Composition Function 4 (N=6)';
        lb = -100; ub = 100;
        opt_f = 2700;

    case {513}
        FunName='WSN (case2)';
        Dim=70;
        lb=zeros(1,Dim);
        ub=50.*ones(1,Dim);

    case{520}
        FunName='Safety-enhanced UAV Path Planning (case3)';
        Dim=30;
        r_lb=0;
        r_ub=184.3909;
        psi_lb=-0.7854;
        psi_ub=0.7854;
        phi_lb=0.0768;
        phi_ub=1.6476;
        lb=[r_lb.*ones(1,10) psi_lb.*ones(1,10) phi_lb.*ones(1,10)];
        ub=[r_ub.*ones(1,10) psi_ub.*ones(1,10) phi_ub.*ones(1,10)];

    case{626}
        FunName='Schutten STP6-120/36 Polycrystalline PV Module (DDM) at 1000W/m² and 55°C (case1)';
        lb=[0, 1e-12, 1e-12, 0.001, 0.001, 1,  1];
        ub=[8, 5e-5,  5e-5,  0.36,  1500,  50, 50];
        Dim=length(lb);

    case{630}
        FunName='Schutten STM6-40/36 Monocrystalline PV Module (DDM) at 1000W/m² and 51°C (case1 old)';
        lb=[0, 1e-12, 1e-12, 0.001, 0.001, 1,  1];
        ub=[2, 5e-5,  5e-5,  0.36,  1000,  60, 60];
        Dim=length(lb);

    case{946}
        FunName='SOPWM for 5-level Inverters (case4)';
        Dim=25;
        lb=-0*ones(1,Dim);
        ub=90*ones(1,Dim);
        opt_f=2.0240335000E-02;
end

%% If lb and ub are not vectors make them vectors
sl = size(lb);

if (sl(1)*sl(2) == 1) % lb and ub are scalers
    LB = lb*ones(1,Dim);
    UB = ub*ones(1,Dim);
else
    LB = lb;
    UB = ub;
end
end